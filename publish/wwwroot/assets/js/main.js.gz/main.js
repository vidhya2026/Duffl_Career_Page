// <!-- AOS --> 
AOS.init({
  duration: 1500,
  once: true
})
// <!-- //AOS --> 
 

 